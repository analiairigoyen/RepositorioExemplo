$('body').append('<div id="ks-previewer"><div id="ksp-one"><a id="ksp-lum-plus">Lum +</a><a id="ksp-lum-minus">Lum -</a><a id="ksp-sat-plus">Sat +</a><a id="ksp-sat-minus">Sat -</a></div><div id="ksp-two"></div><div id="ksp-three"></div><div id="ksp-four"></div><div id="ksp-five"></div><div id="ksp-six"></div></div>');

setColor('red');